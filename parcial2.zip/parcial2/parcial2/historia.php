<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BK_parcial2</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <script src="js/jquery-3.6.1.js"></script>
</head>
<body>

    <style>
        h1{
            font-family: 'Times New Roman', Times, serif;
            font-style: italic;
        }
        p {
            margin: 35px;
        }
    </style>

    <h1> <center> Historia de Burger King </center></h1>
    <center><p>
        Burger King es una de las empresas de comida rápida que con el paso del tiempo se ha mantenido líder en el sector siendo una de las competencias más fuertes de McDonald’s; su creación se dio en 1954 en Miami, Florida cuando James McLamore y David Egerton decidieron fundar este negocio ya que contaban con experiencia en el rubro de los restaurantes, su primer local era un restaurante especializado en hamburguesas y tenía el lema de «como tú quieras» con el cual buscaban ofrecer un servicio diferente y a la vez dejar una huella en cada cliente. Un dato importante sobre el origen es que la idea inicial fue de la pareja Keith Kramer y el tío de su esposa Mateo Burns quienes decidieron abrir su propio restaurante luego de una visita a McDonald’s con el nombre de "Insta-Burger King", fueron vendidos los derechos a James McLamore y David Egerton en 1959 y así fue que acortaron el nombre.
    <br><br></p>
    <div align="center"><IMG SRC="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6djuIu7X8jOG601sKEEgNOoL71o5oHPCZ9w&usqp=CAU" width="500" height="250"></div>  
    <br><br><p>
        Fueron estos dos nuevos dueños de la cadena quienes aportaron innovadoras ideas al restaurante como fue el empacar los panes en bolsas de papel lo cual se copió mucho en años posteriores y ayudó mucho a evitar la contaminación, uno de los productos que más éxito alcanzó en sus inicios fue el Whooper el cual ha sido desde siempre uno de sus platos bandera, el primer local se ubicó en Illinois en 1961, poco después se abrió otro en Champaign en ese mismo estado, el crecimiento de la cadena se disparó ya que para 1967 ya se habían abierto más de 50 restaurantes de Burger King solo en Illinois por lo que en ese momento decidieron expandirse a otros estados. En 1967 la empresa fue comprada por Pillsbury la cual era una compañía con sede en Minneapolis, en ese momento ya contaban con cerca de 8000 empleados y habían abierto en 274 nuevos locales, ya tenía presencia en Florida y por todo el Sur Este de Estados Unidos, un año antes en 1966 ya habían abierto su primera franquicia fuera de suelo norteamericano en las Bahamas.
    <br><br></p>
        Uno de los reconocimientos que tiene esta cadena de comida rápida es que fueron los primeros en implementar comedores y también implementaron los primeros auto-servicios en 1975, este modelo de negocio fue tan popular que a la fecha corresponde al 50%  de todo lo que es Burger King, una de sus campañas de marketing que empezó con más fuerza fue en 1974 y el cual llevó el lema antes mencionado «como tú quieras» y que anunciaba la posibilidad a los clientes de personalizar sus propias hamburguesas, en 1979 el servicio de esta empresa comenzó a incluir desayunos.
    <br><br><p>
    <div align="center"><IMG SRC="https://www.reasonwhy.es/media/library/imagen_vd_1_0.jpg"  width="500" height="250"></div>
    </p></center>


    <footer class="text-center">
        <hr>
        2022 &copy; Duran Moreno Valeria & Nevárez Calderón Laura Yoliztli
    </footer>
    <script src="js/bootstrap.js"></script>
</body>
</html>