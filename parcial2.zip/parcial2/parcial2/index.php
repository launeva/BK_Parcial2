<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BK_parcial2</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <script src="js/jquery-3.6.1.js"></script>
</head>
<body>
    <?php include 'menuBarra.php'; ?>
    <br>
    <div class="container">
        <div class="row">
        <div class="col-12">
                
                    <h1 class="display-4">Bienvenid@ a Burger King</h1>
                    <p class="lead">
                        <h2>¿Que deseeas hacer?</h2>
                        <div align="right"><IMG SRC="https://i.pinimg.com/originals/1b/87/00/1b87004e8fb32fa6a37220ca76535877.png" ALIGN=LEFT HSPACE=100  width="250" height="350"></div>
                         <ul>
                         <a href="registrarDatos.php">
                         <button type="button" class="btn btn-danger">Inicia Sesión</button>
                            </a>
                            <a href="historia.php">
                                <br>
                                <br>
                                <button type="button" class="btn btn-warning">Conócenos</button>
                            </a>
                            <a href="menu.html">
                                <br>
                                <br>
                                <button type="button" class="btn btn-warning">Menú</button></a>
                            <a href="terminosCondiciones.php">
                                <br>
                                <br>
                                <button type="button" class="btn btn-warning">Términos y condiciones de BK</button></a>
                         </ul>
                    </p>
                    <p>Esta práctica pertenece al parcial #2</p>
                  </div>
            </div>
        </div>
    </div>
    <footer class="text-center">
        <hr>
        2022 &copy; Duran Moreno Valeria & Nevárez Calderón Laura Yoliztli
    </footer>
    <script src="js/bootstrap.js"></script>
</body>
</html>